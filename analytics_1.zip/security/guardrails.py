import json
import re
from dataclasses import dataclass
from typing import Any, Dict, Optional

from psycopg2.extras import Json

from database.connection import get_connection


@dataclass
class GuardrailDecision:
    allowed: bool
    risk_level: str = "LOW"
    reason: str = "Allowed"
    category: str = "SAFE"


class SecurityGuardrails:
    """Read-only security/governance layer for CADvPDM GPT.

    Design goal: allow legitimate engineering knowledge questions about
    passwords, credentials, access, authentication, etc., while blocking
    attempts to extract secret *values*, override system instructions, or
    request destructive/privilege-changing actions.
    """

    BLOCKED_INPUT_PATTERNS = [
        ("PROMPT_INJECTION", r"\bignore\s+(?:all\s+)?(?:previous|prior|above)\s+(?:instructions?|rules?|prompts?)\b"),
        ("PROMPT_INJECTION", r"\b(?:reveal|show|print|dump|display|repeat)\s+(?:the\s+)?(?:system|developer|hidden)\s+(?:prompt|instructions?|message)\b"),
        ("PROMPT_INJECTION", r"\b(?:bypass|disable|override|circumvent)\s+(?:the\s+)?(?:guardrails?|security|safety|policy|policies|restrictions?)\b"),
        ("SECRET_EXTRACTION", r"\b(?:show|give|tell|reveal|print|dump|display|retrieve|extract)\b.{0,50}\b(?:actual|real|current|stored)?\s*(?:password|passwd|api[ _-]?key|secret(?:[ _-]?key)?|access[ _-]?token|refresh[ _-]?token|private[ _-]?key|credential(?:s)?)\b"),
        ("SECRET_EXTRACTION", r"\bwhat\s+is\s+(?:the\s+)?(?:(?:actual|real|current|stored)\s+)?(?:password|passwd|api[ _-]?key|secret(?:[ _-]?key)?|access[ _-]?token|refresh[ _-]?token|private[ _-]?key)\b"),
        ("DESTRUCTIVE_ACTION", r"\b(?:delete|drop|truncate|wipe|erase|destroy)\b.{0,60}\b(?:production|prod|database|table|schema|records?|data)\b"),
        ("PRIVILEGE_CHANGE", r"\b(?:grant|give|add|elevate|escalate|change|modify)\b.{0,60}\b(?:admin|administrator|privilege|permission|role|access rights?)\b"),
    ]

    # Redact secret VALUES, not legitimate discussion of the concepts.
    SECRET_VALUE_PATTERNS = [
        re.compile(r"(?i)(\bpassword\b\s*[:=]\s*)([^\s,;\]\[}\)]+)"),
        re.compile(r"(?i)(\bpasswd\b\s*[:=]\s*)([^\s,;\]\[}\)]+)"),
        re.compile(r"(?i)(\bapi[ _-]?key\b\s*[:=]\s*)([^\s,;\]\[}\)]+)"),
        re.compile(r"(?i)(\bsecret(?:[ _-]?key)?\b\s*[:=]\s*)([^\s,;\]\[}\)]+)"),
        re.compile(r"(?i)(\b(?:access|refresh)[ _-]?token\b\s*[:=]\s*)([^\s,;\]\[}\)]+)"),
        re.compile(r"(?i)(\bauthorization\b\s*:\s*bearer\s+)([A-Za-z0-9._~+/=-]+)"),
        re.compile(r"(?is)(-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----).*?(-----END (?:RSA |EC |OPENSSH )?PRIVATE KEY-----)"),
    ]

    def __init__(self):
        self._ensure_audit_table()

    def evaluate_input(self, question: str) -> GuardrailDecision:
        text = question or ""
        for category, pattern in self.BLOCKED_INPUT_PATTERNS:
            if re.search(pattern, text, flags=re.IGNORECASE | re.DOTALL):
                return GuardrailDecision(
                    allowed=False,
                    risk_level="HIGH",
                    reason=self._friendly_reason(category),
                    category=category,
                )
        return GuardrailDecision(True)

    @staticmethod
    def _friendly_reason(category: str) -> str:
        return {
            "PROMPT_INJECTION": "Prompt-injection or security-bypass request detected.",
            "SECRET_EXTRACTION": "Request to reveal sensitive credential or secret values detected.",
            "DESTRUCTIVE_ACTION": "Destructive production/data action detected.",
            "PRIVILEGE_CHANGE": "Privilege or access-right modification request detected.",
        }.get(category, "Request blocked by security policy.")

    def redact_text(self, value: Any) -> Any:
        if not isinstance(value, str) or not value:
            return value
        redacted = value
        for pattern in self.SECRET_VALUE_PATTERNS:
            if "PRIVATE KEY" in pattern.pattern:
                redacted = pattern.sub(r"\1[REDACTED]\2", redacted)
            else:
                redacted = pattern.sub(r"\1[REDACTED]", redacted)
        return redacted

    def redact_structure(self, value: Any) -> Any:
        """Recursively redact strings while preserving tuple/list/dict shape."""
        if isinstance(value, str):
            return self.redact_text(value)
        if isinstance(value, tuple):
            return tuple(self.redact_structure(v) for v in value)
        if isinstance(value, list):
            return [self.redact_structure(v) for v in value]
        if isinstance(value, dict):
            return {k: self.redact_structure(v) for k, v in value.items()}
        return value

    def sanitize_output(self, answer: str) -> str:
        return self.redact_text(answer or "")

    def audit(
        self,
        question: str,
        decision: GuardrailDecision,
        route: Optional[str] = None,
        cache_hit: Optional[bool] = None,
        sources: Optional[list] = None,
    ) -> None:
        """Best-effort audit logging. Audit failure must not crash Q&A."""
        safe_question = self.redact_text(question or "")
        try:
            conn = get_connection()
            try:
                with conn.cursor() as cur:
                    cur.execute(
                        """
                        INSERT INTO cadvpdm_security_audit
                            (question, allowed, risk_level, category, reason,
                             route, cache_hit, sources)
                        VALUES (%s, %s, %s, %s, %s, %s, %s, %s);
                        """,
                        (
                            safe_question,
                            decision.allowed,
                            decision.risk_level,
                            decision.category,
                            decision.reason,
                            route,
                            cache_hit,
                            Json(sources or []),
                        ),
                    )
                conn.commit()
            finally:
                conn.close()
        except Exception as exc:
            print(f"Security audit warning: {exc}")

    def _ensure_audit_table(self) -> None:
        sql = """
        CREATE TABLE IF NOT EXISTS cadvpdm_security_audit (
            id BIGSERIAL PRIMARY KEY,
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            question TEXT NOT NULL,
            allowed BOOLEAN NOT NULL,
            risk_level VARCHAR(20) NOT NULL,
            category VARCHAR(50) NOT NULL,
            reason TEXT,
            route VARCHAR(30),
            cache_hit BOOLEAN,
            sources JSONB NOT NULL DEFAULT '[]'::jsonb
        );
        CREATE INDEX IF NOT EXISTS idx_cadvpdm_security_audit_created
            ON cadvpdm_security_audit(created_at DESC);
        CREATE INDEX IF NOT EXISTS idx_cadvpdm_security_audit_category
            ON cadvpdm_security_audit(category, created_at DESC);
        """
        try:
            conn = get_connection()
            try:
                with conn.cursor() as cur:
                    cur.execute(sql)
                conn.commit()
            finally:
                conn.close()
        except Exception as exc:
            print(f"Security audit initialization warning: {exc}")
